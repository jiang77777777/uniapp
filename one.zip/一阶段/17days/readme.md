# 帧动画
## 1、定义关键帧
- 1）
```
@keyframes 动画名称（英文）{
    0%{ 动画开始 }
    50%{ }
    100%{ 动画结束 }
}
```
- 2） 
```
@keyframes 动画名称（英文）{
    from{ 动画开始 }
    to{ 动画结束 }
}
```
## 2、引用帧动画
```
animation: animation-name animation-duration animation-timing-function animation-delay animation-iteration-count animation-direction animation-fill-mode;
animation: 动画名称 动画的执行时间 动画速度曲线 延迟时间 动画播放的次数 动画运动方向 动画结束之后的显示状态;
```
- 动画速度曲线: linear  ease ease-in  ease-out ease-in-out
- 动画播放次数：n表示次数  infinite无限循环 默认执行次数为1
- 动画运动方向
    - normal 默认值，正常播放
    - alternate 正向反向轮流播放
    - reverse 反向
    - alternate-reverse  反向正向轮流播放
- 动画结束之后的显示的状态
    - both 动画开始或结束时的状态
    - forwards 动画结束时的状态
    - backwards 动画开始时的状态
> 必须要设置动画名称和动画的执行时间
# animate.css动画插件
    https://animate.style/
    css3动画库，预设了抖动（shake）、闪烁（flash）、弹跳（bounce）、旋转（rotateIn|rotateOut）、翻转（flip）、淡入淡出（fadeIn|fadeOut）等动画效果。
## 使用方法：
- 1、引入animate.css文件
```
<link rel="stylesheet" href="css/animate.min.css">
```
- 2、使用
    <p class="txt animate__animated animate__fadeIn">内容内容</p>
    .animate__animated类名，表示基本类名，必须要添加
    .animate__fadeIn类名，表示动画的样式名
## css3中过渡和动画的区别和各自的使用场景？
- 区别：语法、触发、执行次数、复杂度

# 弹性盒子
## 1、什么是弹性盒子？
- 传统布局
    - 兼容性好
    - 布局繁琐
    - 局限性，不能再移动端有很好的布局
    - PC端页面中更多的使用传统布局
- flex布局
    弹性盒子是css3新增布局方式——一种当页面需要使用不同屏幕大小、不同的设备类型时，能够确保元素拥有恰当行为的布局方式
    - 操作方便，布局简单，移动端使用广泛
    - PC端浏览器支持情况较差
    - IE11或更低版本中，不支持或部分支持
    - 在盒模型中较为灵活
- 弹性盒模型的内容包括：弹性容器、弹性子元素——项目
- 引入弹性盒模型的目的：用一种更加有效的方式对容器中的子元素进行排列、对齐、分配空白空间。即使弹性子元素的尺寸发生动态改变，弹性盒模型也可以正常工作
- 原理：为父元素设置flex属性，控制子元素的位置及排列方式
## 2、设置弹性盒子——display属性
- display: flex; 将盒子设置为弹性盒
- display: inline-flex; 将盒子设置为弹性盒
> 将容器设置为flex布局之后，子元素中的float、clear、vertical-align属性都会失效
## 3、基本概念
- flex容器、项目——弹性子元素
- 默认在容器中有两根轴线
    - 默认主轴方向——x轴方向，水平向右（左侧为主轴起点，右侧为主轴终点）
    - 默认交叉轴方向——y轴方向，水平向下（上方为交叉轴起点，下方交叉轴终点
## 4、容器属性——添加弹性容器上
- flex-direction属性：设置主轴的方向，子元素的排列方向
    - flex-direction: row; 默认值，主轴方向为水平方向，起点在左侧排列次序与文档顺序一致
    - flex-direction: row-reverse; 主轴方向为水平方向，起点在右侧排列次序与文档顺序相反
    - flex-direction: column; 主轴方向为垂直方向，起点在上方排列次序与文档顺序一致
    - flex-direction: column-reverse; 主轴方向垂直方向，起点在下方排列顺序为从下到上
- justify-content 属性：弹性子元素在主轴方向上的对齐方式
    - justify-content: flex-start; 默认值，子元素位于弹性容器的开头
    - justify-content: flex-end; 子元素位于弹性容器的结尾
    - justify-content: center; 子元素位于弹性容器的中心
    - justify-content: space-between; 子元素和子元素之间有空白空间
    - justify-content: space-around; 子元素之前、之间、之后都留有空白空间，且空间自行分配
- align-items属性：弹性子元素在交叉轴上的对齐方式
    - align-items: stretch; 默认值，如果弹性子元素没有高度或高度为auto，将占满整个容器的高度
    - align-items: flex-start;子元素位于交叉轴的起点
    - align-items: flex-end; 子元素位于交叉轴的终点
    - align-items: center; 子元素位于交叉轴的中间
    - align-items: baseline; 子元素在第一行文字的基线对齐
- flex-wrap属性：弹性子元素在一根轴线上排不下时，的换行方式
    - flex-wrap: wrap; 换行，第一行显示在上方
    - flex-wrap: wrap-reverse; 换行，第一行显示在下方
    - flex-wrap: nowrap; 默认值，不换行
- align-content属性：多根轴线的对齐方式，如果只有一根轴线，属性失效
    - align-content: flex-start; 与交叉轴的起点对齐
    - align-content: flex-end; 与交叉轴的终点对齐
    - align-content: center; 与交叉轴的中点对齐
    - align-content: space-between; 轴线之间有间距
    - align-content: space-around; 轴线两侧都有间距
    - align-content: stretch; 默认值，轴线占满整个交叉轴
## 5、项目属性——写在弹性子元素上
- order属性；子元素的排列次序
    - 属性值为数值，没有单位，默认数值为0，数值越小，排列越靠前
- flex-grow属性：子元素的放大比例
    - 属性值为数值，没有单位，默认值为0，表示不放大
- flex-shrink属性：子元素的缩小比例
    - 属性值为数值，没有单位
    - 默认值为1，表示当空间不足时，等比例缩小
    - 属性值为0，表示当空间不足时，不缩小
    - 负值对该属性无效
- align-self属性：弹性容器中被选中子项的对齐方式
    - align-self:auto; 默认值，元素继承了父容器的align-items属性，如果没有父容器则属性值为stretch
    - align-self: stretch; 占满整个容器的高度
    - align-self: flex-start; 交叉轴起点对齐
    - align-self: flex-end; 交叉轴终点对齐
    - align-self: center; 交叉轴中点对齐
    - align-self: baseline; 子元素的第一行文字的基线对齐
# calc()函数
- 用于动态计算长度值，值灵活
- css3新增功能
- 好处：适用于流体布局，可以通过calc()计算得到元素的宽度
    流体布局（屏幕分辨率发生变化，元素大小会变化但是布局不变）
- 可以用来实现加减乘除四则运算
- 语法：
    calc(表达式)
```
 width: calc(100%-200px);  语法错误，减号的前后添加空格
 ```
 > 运算符的前后添加空格
 - 浏览器支持
    在IE9+、Firefox、chrome、safari可以正常呈现
- 利用calc()实现三列自适应布局

# css预处理
## 1、预处理
- 是一种新的语言
- 基本思想：用一种专门的编程语言，为css增加一些编程的特性，将css目标生成文件，然后开发者使用预处理语言进行编码工作
## 2、less
- 包含一套自定义的语法及一个解析器，用户根据语法定义自己的样式规则，这些规则最终通过解析器编译生成对应css文件，只有被编译后的文件才能被浏览器识别
- 扩展css语言，添加一些新的功能，如：定义变量、混合、函数、运算等，让css更具有维护性、扩展性
- 好处：
    结构清晰，便于扩展；可以方便地屏蔽浏览器私有语法差异；可以实现多重继承；完全兼容css代码，可以方便地应用到老项目中。
## 3、预处理编译工具Koala
## 4、less基本语法
### 1）新建一个less文件
    新建文件后缀名为.less
    新建一个后缀名为.less的文件；打开Koala并将文件拖拽到目录列表中；右击设置输出路径，选择正确的输出路径，输入文件名，单击确定；执行编译；在html文件中将编译好的css文件链入
### 2）注释
    less提供了两种注释风格
- /* */标准css注释，会保留在编译后的文件中
- //单行注释，只在less源文件中保留，编译后被省略
### 3）import导入样式
    可以导入css文件、less文件
    @import必须在样式表头部最先声明，后面必须加分号。
- 语法
```
@import "*.css";
@import url(*.css);
@import url("*.css");
```
#### link和@import的区别：
- link是HTML标签；@import是css中定义的，只能加载css
- link在页面载入时同时载入；@import在页面加载完成后加载
- link无兼容问题，支持使用JavaScript修改样式；@import在css2.1以下浏览器中不支持。JavaScript只能控制DOM去改变link标签引入的样式，而@import的样式不是DOM可以控制的，不支持JavaScript改变样式