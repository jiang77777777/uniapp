# Grid布局——网格布局
- flex布局：轴线布局，只能在指定的轴线上排列，可以看作一维布局
- grid布局：二维布局，水平方向和垂直方向同时存在
## 1、基本概念
- 容器container：采用网格布局的区域
- 项目item：容器内采用网格定位的子元素

- 行row：容器中的水平区域
- 列column：容器中的垂直区域

- 单元格cell：行列交叉区域，正常情况下，m行n列 m*n个单元格

- 网格线grid line：划分网格的线。
    - 水平网格线   行
    - 垂直网格线   列
    正常情况下，m行有 m+1根水平网格线   n列有 n+1根垂直网格线
## 2、属性
- 容器属性
- 项目属性
### 1）容器属性
- display属性：指定容器使用网格布局
    - display: grid; 
    - display: inline-grid;
- grid-template-rows属性、grid-template-columns属性 划分网格的行列
    - 属性值单位px、百分比、auto、fr(对网格剩余空间比例单位，值的大小必须大于等于1，否则会有空余空间)
    - repat() 重复 可以设置两个参数，第一个参数为重复次数，第二个参数重复值
    - minmax() 长度范围，两个参数，分别表示最大值和最小值
    - 网格线名称
    ```
    grid-template-rows: [r1] 100px [r2] auto [r3] 100px;
    grid-template-columns: [c1] 100px [c2] 100px [c3] auto ;
    ```
- grid-row-gap属性、grid-column-gap属性、grid-gap属性：设置网格间隙
    - grid-gap: grid-row-gap gird-column-gap;
    ```
    grid-row-gap: 10px;/* 行间隙 */
    grid-column-gap: 40px;/* 列间隙 */
    grid-gap: 10px;/* 行和列之间都有10像素间隙 */
    grid-gap: 10px 50px;/* 行间隙10px，列间隙50px */
    ```
- grid-auto-flow属性 划分网格后，对容器中子元素的排列顺序的设置
    - grid-auto-flow: row; 默认值，先行后列
    - grid-auto-flow: column; 先列后行
- justify-items属性、align-items属性、place-items属性 内容的分布
    - justify-items属性：设置网格元素的水平呈现方式
    - align-items属性：设置网格元素的垂直呈现方式
    - place-items: align-items justify-items;
    属性值：
    - start  单元格左侧或顶端对齐
    - end  单元格右侧或底端对齐
    - center 单元格中间对齐
    - stretch; 占满单元格的整个宽度或高度，默认值
- justify-content属性、align-content属性、place-content属性  元素布局
    - justify-content属性：设置网格元素的水平分布方式
    - align-content属性：设置网格元素的垂直分布方式
    - place-content：align-content justify-content;
    属性值：
    - start 容器的起始位置
    - end 容器的结束位置
    - center 容器的中间位置
    - space-between; 项目之间有间隔
    - space-around; 项目之间、之前、之后都有间隔，并且项目之间的间隔比与容器之间的间隔大
    - space-evenly; 项目之前、之间、之后都有间隔，并且间隔相等 
- grid-template-areas属性 定义网格区域
```
.wrap{
    display: grid;
    grid-template-rows: repeat(3,100px);
    grid-template-columns: repeat(3,100px);

    grid-template-areas: "b1 b1 b1"
                        "b2 b2 b3"
                        "b2 b2 b3";/* 按照名称分3类，只要3个元素 */
}
在结构中将项目设置为3个
将3个项目分别放在对应的区域——grid-area属性
.wrap div:nth-child(1){
    grid-area: b1;/* 指定项目放在哪个区域 */
}
.wrap div:nth-child(2){
    grid-area: b2;
}
.wrap div:nth-child(3){
    grid-area: b3;
}
```
## 2、项目属性
- 指定项目位置
    - grid-column-start属性 项目的左边在哪根网格线上
    - grid-column-end属性 项目的右边在哪根网格线上
    - grid-row-start属性 项目的上边在哪根网格线上
    - grid-row-end属性  项目的下边在哪根网格线上

    - grid-column: grid-column-start/grid-column-end;
    - grid-row: grid-row-start/grid-row-end;
- 单元格内容对齐方式
    - justify-self属性 单元格内容水平对齐方式
    - align-self属性 单元格内容的垂直对齐方式
    - place-self: align-self justify-self;
    属性值：
    - start 单元格起始位置
    - end 单元格结束位置
    - center 单元格中间
    - stretch 默认值，拉伸，占满整个单元格
```
<a href="mailto:111@163.com">111@163.com</a>
>点击之后会直接打开邮件客户端，在收件人111@163.com

<a href="sms:10086,10010?body=ABC">发送信息</a> 
> 为10086和10010发送内容为ABC的短信

<a href="tel:400400400">400-400-400</a>
>点击后直接拨打400400400

<a href="图片地址" download="图片名称">下载图片</a>
```