```
<a href="maito:111@163.com">111.@163.com</a>点击之后直接打开邮件客户端
<a heff="sms:10086.10010?body=abc">发送信息</a> 发送信息给。。。 内容为abc
<a href="tel:40000">4000</a>点击直接拨打
<a heff="图片地址" download=“>
```

