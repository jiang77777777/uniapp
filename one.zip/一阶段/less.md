5）混入

将一种或一系列的属性从一个规则集引入到另一个规则集

- 混入类名：定义通用属性，放在一个class名称中，在另一个类名中调用已经定义好的类
  - 定义通用属性；
    - .fon{font-size:30px;}在解析后的文件中可以看到
    - .fo(){font-size:30px;}在解析后的文件中看不到
  -  调用定义好的类

```
.box{.fon;.fo;}
```

 

- 混入参数

  - 定义：

  - ```
    .boRa(@radius){
    
    border-radius:@radius;
    
    }
    ```

  - 使用          ：

  - ```
    .boRa(50px);
    ```

  - 

> 混入参数没有设置默认值，调用时必须传入参数

- 混入参数——默认值

  - 定义：

  ​    .si(@size:100px){height:@size;}

  - 调用：

​         .box{.si;.si(200px);}



> 混入参数并设置默认值，调用时如果不写传入参数，相当于使用默认值



- 使用@arguments 来引用所有传入的参数

  - 定义

    .bor(@bw,@bs,@bc){border:@arguments;}

    .bore(@bw:10px,@bs:solid,@bc:blue){border:@arguments;}

  - 调用

  ​     .bor(10px,solid,blue);

  ​    .bore(20px);

  ​    .bore

### 6) 嵌套

模仿HTML结构，让css代码结构更加清晰、明了

- 选择器嵌套

  - 在嵌套的代码块中，使用&引用父元素

  .wrap  more{

  &:hover{

  background:blue

  }

  }

  .mo(){

  &:hover{

  background:blue

  }

  }

  .warp .more{ .mo();}

     ### 7)继承

extend 伪类实现样式的继承

- 定义哟啊继承的类

    .fontSty{font-style:italic;}

- 调用：

  .box4:extend(.fontSty){

  css样式}

  .box4{

  &:extend(.fontSty)

  css样式}

### 8）运算

数值、颜色、变量都可以进行运算

- 1）数值运算

  less回自动推算数单位

- 2）颜色运算

​      先将颜色色值转换为rgb模式，然后运算，最后将运算后的结果转换为十六进制并返回

##终点##

```
width：calc(~"100% - 20px")
```



​      